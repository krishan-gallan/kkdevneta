# Module 3: Working with Structured Data and Local Version Control
This contains the files for the CRM application with the relevant updates
made in this module. Note that these files are also used for
`Module 4: Creating and Managing Basic Github Repositories` but all
variants of the US dollars display are retained in the code, but commented
out. This makes it easy to toggle between different styles for version
control testing.
