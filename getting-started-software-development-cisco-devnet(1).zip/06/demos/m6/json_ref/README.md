# JSON references files
These are examples of HTTP body text that comes back from DNA center
after issuing certain requests. These may save you some exploratory
debugging when you are trying to access nested JSON data for specific
actions, such as getting devices, adding devices, or deleting devices.
