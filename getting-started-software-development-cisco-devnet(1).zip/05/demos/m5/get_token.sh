curl -X POST \
  -u 'devnetuser:Cisco123!' \
  -H 'Content-Type: application/json' \
  https://sandboxdnac.cisco.com/dna/system/api/v1/auth/token
